last_time = nil;
scroll_speed = 5.0;
delta_time = 1;
world_width = 2048;

function Scene_OnTick(_scene)

	-- Calculate frame scaling factor
	local this_time = sys.getTimeMs();
	if (last_time ~= nil) then
		delta_time = (this_time - last_time) / 16.76;
		last_time = this_time;
	end

	-- Scroll the scene
	scene.add(_scene, "PositionX", tostring(scroll_speed * delta_time));
	
	-- Wrap the scene at its extents
	local pos_x = scene.get(_scene, "PositionX");
	if (pos_x > world_width / 2) then 
		pos_x = pos_x - world_width;
		scene.set(_scene, "PositionX", tostring(pos_x));
	end
	
	-- Move player to keep in line with centre of screen
	local player = actor.find("player", _scene);
	if (player ~= nil) then 
		actor.add(player, "PositionX", scroll_speed * delta_time);
		pos_x = actor.get(player, "PositionX");
		if (pos_x > world_width / 2) then 
			pos_x = pos_x - world_width;
			actor.set(player, "PositionX", tostring(pos_x));
		end
	end
	
	return 1;
end

function CreateBullet(_parent)

	-- Get players position
	local scene = actor.get(_parent, "Scene");
	local player = actor.find("player", scene);
	local player_pos = actor.get(player, "Position");
	
	-- Find template
	local bullet_template = resource.find("BulletTemplate", "template", scene);
	
	-- Create template parameters table
	local params = {};
	params["name"] = "bullet";
	params["pos"] = tostring(player_pos.x + 40) .. "," .. tostring(player_pos.y);
	
	-- Instantiate the template
	template.from(bullet_template, scene, params);
	
	print("Bullet created");

	return 1;
end

function Bullet_Tick(_bullet)

	-- If bullet exits edge of world then destroy it
	local scene = actor.get(_bullet, "Scene");
	local pos_x = actor.get(_bullet, "PositionX");
	if (pos_x > world_width / 2) then 
		pos_x = pos_x - world_width;
		actor.set(_bullet, "PositionX", tostring(pos_x));
		actor.destroy(_bullet);
	end


	return 1;
end
















