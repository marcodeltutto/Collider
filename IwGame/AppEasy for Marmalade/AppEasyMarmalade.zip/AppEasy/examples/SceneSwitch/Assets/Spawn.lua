local total_objects = 0;
local last_time = 0;
local crate_template = nil;

function Scene_OnTick(_object)

	-- Dont allow more than 100 objects to be spawned
	if (total_objects > 100) then 
		return 1;
	end
	
	local this_time =  os.time();

	-- Spawn a new object every few seconds
	if ((this_time - last_time) > 1) then
	
		print("Spawning new crate");

		-- Find template
		if (crate_template == nil) then
			crate_template = template.find("CrateTemplate", _object);
			print("Cached tenmplate");
		end
		
		-- Create template parameters
		local params = {};
		params["pos"] = "0, -400";
		
		-- Instantiate the template
		template.from(crate_template, _object, params);
		
		total_objects = total_objects + 1;
		
		last_time = this_time;
		
	
	end

	return 1;
	
end